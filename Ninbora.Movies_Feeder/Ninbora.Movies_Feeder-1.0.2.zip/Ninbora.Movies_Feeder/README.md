======================
GOmovies_HebSub_Feeder XBMC Addon
======================

About
-----
Feed GOmovies from sources

License
-------
This software is released under the [MIT license] [1].
[1]: http://opensource.org/licenses/MIT